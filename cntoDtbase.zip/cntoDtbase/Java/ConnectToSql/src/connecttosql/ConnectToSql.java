
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectToSql {

    public static void main(String[] args) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=QuanLyLop;encrypt=true;trustServerCertificate=true;";
        String username = "sa"; // Thay đổi nếu cần
        String password = "123456789"; // Thay đổi nếu cần

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Kết nối đến cơ sở dữ liệu
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Kết nối thành công!");

            // Tạo một Statement
            stmt = conn.createStatement();

            // Thực hiện truy vấn SQL
            String sql = "SELECT * FROM tbl_lop"; // Thay bằng tên bảng thực tế
            rs = stmt.executeQuery(sql);

            // Duyệt qua kết quả và in ra tối đa 5 bản ghi
            int count = 0;
            while (rs.next() && count < 5) { // Giới hạn số lượng bản ghi in ra là 5
                String id = rs.getString("malop"); // Sửa lại thành getString
                String name = rs.getString("tenlop"); // Thay đổi 'name' bằng tên cột thực tế
                System.out.println("Mã lớp: " + id + ", Tên lớp: " + name);
                count++;
            }
        } catch (SQLException e) {
            System.out.println("Lỗi SQL: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Lỗi khác: " + e.getMessage());
        } finally {
            // Đóng ResultSet, Statement, và Connection
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Lỗi khi đóng kết nối: " + e.getMessage());
            }
        }
    }
}
