# Java
![Screenshot (520)](https://github.com/user-attachments/assets/0c3fe8e8-54dc-4db2-9baa-4df512eece74)
![Screenshot (521)](https://github.com/user-attachments/assets/7f6ed2b8-176b-4996-9bfc-2dba451e8a15)
